(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0wx_ksp._.js","static/chunks/node_modules_next_0mgv4n8._.js"],
    source: "dynamic"
});
